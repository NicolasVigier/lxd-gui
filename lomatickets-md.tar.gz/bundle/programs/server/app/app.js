var require = meteorInstall({"lib":{"methods":{"agents-methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/methods/agents-methods.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
                                                                                                               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users-methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/methods/users-methods.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.methods({});                                                                                            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"router":{"acl.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/acl.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var requireLogin = function requireLogin() {                                                                   // 1
  if (!Meteor.user()) {                                                                                        // 2
    this.render('accessDenied');                                                                               // 3
  } else {                                                                                                     // 4
    this.next();                                                                                               // 5
  }                                                                                                            // 6
};                                                                                                             // 7
                                                                                                               //
var toLandingPage = function toLandingPage() {                                                                 // 9
  if (!Meteor.user()) {                                                                                        // 10
    this.render('landingPage');                                                                                // 11
  } else {                                                                                                     // 12
    this.next();                                                                                               // 13
  }                                                                                                            // 14
};                                                                                                             // 15
                                                                                                               //
var requireAgent = function requireAgent() {                                                                   // 17
  var appUser = AppUsers.findOne({ userId: Meteor.userId() });                                                 // 18
  if (appUser.user_role == 'Client') {                                                                         // 19
    this.render('accessDenied');                                                                               // 20
  } else {                                                                                                     // 21
    this.next();                                                                                               // 23
  }                                                                                                            // 24
};                                                                                                             // 25
                                                                                                               //
Router.onBeforeAction(requireLogin, { except: ['registerPage', 'landingPage'] });                              // 27
                                                                                                               //
Router.onBeforeAction(toLandingPage, { only: 'landingPage' });                                                 // 29
                                                                                                               //
Router.onBeforeAction(requireAgent, { except: ['ticketsHome', 'search', 'ticketPage', 'ticketSubmit', 'registerPage', 'landingPage'] });
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-admin-global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-admin-global.js                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/admin', {                                                                                       // 1
  name: 'adminTicketsHome',                                                                                    // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', true);                                                                         // 4
      return Meteor.subscribe('myTicketsAssignedAll');                                                         // 5
    }                                                                                                          // 6
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 7
    function data() {}                                                                                         // 7
                                                                                                               //
    return data;                                                                                               // 7
  }()                                                                                                          // 7
});                                                                                                            // 1
                                                                                                               //
Router.route('/admin/pool/:_id', {                                                                             // 12
  name: 'adminPoolView',                                                                                       // 13
  waitOn: function () {                                                                                        // 14
    function waitOn() {                                                                                        // 14
      Meteor.subscribe('usersList');                                                                           // 15
      Meteor.subscribe('userRolesList');                                                                       // 16
      return Meteor.subscribe('appUsersList');                                                                 // 17
    }                                                                                                          // 18
                                                                                                               //
    return waitOn;                                                                                             // 14
  }(),                                                                                                         // 14
  data: function () {                                                                                          // 19
    function data() {                                                                                          // 19
      return AppUsers.findOne(this.params._id);                                                                // 20
    }                                                                                                          // 21
                                                                                                               //
    return data;                                                                                               // 19
  }()                                                                                                          // 19
});                                                                                                            // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-admin-helpTopics.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-admin-helpTopics.js                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/admin/helptopics', {                                                                            // 1
  name: 'helpTopicsHome',                                                                                      // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', true);                                                                         // 4
      Meteor.subscribe('teamsList');                                                                           // 5
      return Meteor.subscribe('helpTopicsList');                                                               // 6
    }                                                                                                          // 7
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 8
    function data() {}                                                                                         // 8
                                                                                                               //
    return data;                                                                                               // 8
  }()                                                                                                          // 8
});                                                                                                            // 1
                                                                                                               //
Router.route('/admin/helptopic/:_id', {                                                                        // 13
  name: 'helpTopicView',                                                                                       // 14
  waitOn: function () {                                                                                        // 15
    function waitOn() {                                                                                        // 15
      Session.set('hasSidebar', false);                                                                        // 16
      Meteor.subscribe('teamsList');                                                                           // 17
      return Meteor.subscribe('helpTopicsList');                                                               // 18
      //    return Meteor.subscribe('organizationItem', this.params._id);                                      // 19
    }                                                                                                          // 20
                                                                                                               //
    return waitOn;                                                                                             // 15
  }(),                                                                                                         // 15
  data: function () {                                                                                          // 21
    function data() {                                                                                          // 21
      return HelpTopics.findOne(this.params._id);                                                              // 22
    }                                                                                                          // 23
                                                                                                               //
    return data;                                                                                               // 21
  }()                                                                                                          // 21
});                                                                                                            // 13
                                                                                                               //
Router.route('/admin/helptopics/submit', {                                                                     // 26
  name: 'helpTopicSubmit',                                                                                     // 27
  waitOn: function () {                                                                                        // 28
    function waitOn() {                                                                                        // 28
      Session.set('hasSidebar', false);                                                                        // 29
      return Meteor.subscribe('teamsList');                                                                    // 30
    }                                                                                                          // 31
                                                                                                               //
    return waitOn;                                                                                             // 28
  }()                                                                                                          // 28
});                                                                                                            // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-admin-organizations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-admin-organizations.js                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/admin/organizations', {                                                                         // 1
  name: 'organizationsHome',                                                                                   // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', true);                                                                         // 4
      Meteor.subscribe('responsiblesList');                                                                    // 5
      return Meteor.subscribe('organizationsList');                                                            // 6
    }                                                                                                          // 7
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 8
    function data() {}                                                                                         // 8
                                                                                                               //
    return data;                                                                                               // 8
  }()                                                                                                          // 8
});                                                                                                            // 1
                                                                                                               //
Router.route('/admin/organization/:_id', {                                                                     // 13
  name: 'organizationView',                                                                                    // 14
  waitOn: function () {                                                                                        // 15
    function waitOn() {                                                                                        // 15
      Session.set('hasSidebar', false);                                                                        // 16
      Meteor.subscribe('responsiblesList');                                                                    // 17
      return Meteor.subscribe('organizationsList');                                                            // 18
      //    return Meteor.subscribe('organizationItem', this.params._id);                                      // 19
    }                                                                                                          // 20
                                                                                                               //
    return waitOn;                                                                                             // 15
  }(),                                                                                                         // 15
  data: function () {                                                                                          // 21
    function data() {                                                                                          // 21
      return Organizations.findOne(this.params._id);                                                           // 22
    }                                                                                                          // 23
                                                                                                               //
    return data;                                                                                               // 21
  }()                                                                                                          // 21
});                                                                                                            // 13
                                                                                                               //
Router.route('/admin/organizations/submit', {                                                                  // 26
  name: 'organizationSubmit',                                                                                  // 27
  waitOn: function () {                                                                                        // 28
    function waitOn() {                                                                                        // 28
      Session.set('hasSidebar', false);                                                                        // 29
      Meteor.subscribe('clientsList');                                                                         // 30
      return Meteor.subscribe('organizationsList');                                                            // 31
    }                                                                                                          // 32
                                                                                                               //
    return waitOn;                                                                                             // 28
  }()                                                                                                          // 28
});                                                                                                            // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-admin-teams.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-admin-teams.js                                                                            //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/admin/teams', {                                                                                 // 1
  name: 'teamsHome',                                                                                           // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', true);                                                                         // 4
      Meteor.subscribe('agentsList');                                                                          // 5
      return Meteor.subscribe('teamsList');                                                                    // 6
    }                                                                                                          // 7
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 8
    function data() {}                                                                                         // 8
                                                                                                               //
    return data;                                                                                               // 8
  }()                                                                                                          // 8
});                                                                                                            // 1
                                                                                                               //
Router.route('/admin/team/:_id', {                                                                             // 13
  name: 'teamView',                                                                                            // 14
  waitOn: function () {                                                                                        // 15
    function waitOn() {                                                                                        // 15
      Session.set('hasSidebar', false);                                                                        // 16
      Meteor.subscribe('agentsList');                                                                          // 17
      return Meteor.subscribe('teamsList');                                                                    // 18
      //    return Meteor.subscribe('organizationItem', this.params._id);                                      // 19
    }                                                                                                          // 20
                                                                                                               //
    return waitOn;                                                                                             // 15
  }(),                                                                                                         // 15
  data: function () {                                                                                          // 21
    function data() {                                                                                          // 21
      return Teams.findOne(this.params._id);                                                                   // 22
    }                                                                                                          // 23
                                                                                                               //
    return data;                                                                                               // 21
  }()                                                                                                          // 21
});                                                                                                            // 13
                                                                                                               //
Router.route('/admin/teams/submit', {                                                                          // 26
  name: 'teamSubmit',                                                                                          // 27
  waitOn: function () {                                                                                        // 28
    function waitOn() {                                                                                        // 28
      Session.set('hasSidebar', false);                                                                        // 29
      Meteor.subscribe('agentsList');                                                                          // 30
      return Meteor.subscribe('teamsList');                                                                    // 31
    }                                                                                                          // 32
                                                                                                               //
    return waitOn;                                                                                             // 28
  }()                                                                                                          // 28
});                                                                                                            // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-admin-users.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-admin-users.js                                                                            //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
//Router.route('/admin/users', {                                                                               // 1
//  name: 'usersHome',                                                                                         // 2
//  waitOn: function () {                                                                                      // 3
//    return Meteor.subscribe('usersList');                                                                    // 4
//  },                                                                                                         // 5
//  data: function () {                                                                                        // 6
//                                                                                                             // 7
//  }                                                                                                          // 8
//});                                                                                                          // 9
                                                                                                               //
Router.route('/admin/users/role/:role', {                                                                      // 11
  name: 'usersHome',                                                                                           // 12
  waitOn: function () {                                                                                        // 13
    function waitOn() {                                                                                        // 13
      Session.set('hasSidebar', true);                                                                         // 14
      Session.set('filterUserRole', this.params.role);                                                         // 15
      return Meteor.subscribe('usersList');                                                                    // 16
    }                                                                                                          // 17
                                                                                                               //
    return waitOn;                                                                                             // 13
  }(),                                                                                                         // 13
  data: function () {                                                                                          // 18
    function data() {                                                                                          // 18
      return AppUsers.find({ user_role: this.params.role });                                                   // 19
    }                                                                                                          // 20
                                                                                                               //
    return data;                                                                                               // 18
  }()                                                                                                          // 18
});                                                                                                            // 11
                                                                                                               //
Router.route('/admin/appUser/:_id', {                                                                          // 23
  name: 'adminAppUserView',                                                                                    // 24
  waitOn: function () {                                                                                        // 25
    function waitOn() {                                                                                        // 25
      Session.set('hasSidebar', false);                                                                        // 26
      Meteor.subscribe('usersList');                                                                           // 27
      Meteor.subscribe('userRolesList');                                                                       // 28
      return Meteor.subscribe('appUsersList');                                                                 // 29
    }                                                                                                          // 30
                                                                                                               //
    return waitOn;                                                                                             // 25
  }(),                                                                                                         // 25
  data: function () {                                                                                          // 31
    function data() {                                                                                          // 31
      return AppUsers.findOne(this.params._id);                                                                // 32
    }                                                                                                          // 33
                                                                                                               //
    return data;                                                                                               // 31
  }()                                                                                                          // 31
});                                                                                                            // 23
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-agent-tickets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-agent-tickets.js                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/agent', {                                                                                       // 1
  name: 'agentTicketsHome',                                                                                    // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', false);                                                                        // 4
      return Meteor.subscribe('myTicketsAssignedAll');                                                         // 5
    }                                                                                                          // 6
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 7
    function data() {}                                                                                         // 7
                                                                                                               //
    return data;                                                                                               // 7
  }()                                                                                                          // 7
});                                                                                                            // 1
                                                                                                               //
Router.route('/agent/ticket/:_id', {                                                                           // 12
  name: 'agentTicketView',                                                                                     // 13
  waitOn: function () {                                                                                        // 14
    function waitOn() {                                                                                        // 14
                                                                                                               //
      Session.set('hasSidebar', false);                                                                        // 16
                                                                                                               //
      Meteor.subscribe('helpTopicsList');                                                                      // 18
      Meteor.subscribe('prioritiesList');                                                                      // 19
      Meteor.subscribe('statusList');                                                                          // 20
      Meteor.subscribe('agentsList');                                                                          // 21
      Meteor.subscribe('teamsList');                                                                           // 22
      return Meteor.subscribe('myTicketsAssignedAll');                                                         // 23
    }                                                                                                          // 24
                                                                                                               //
    return waitOn;                                                                                             // 14
  }(),                                                                                                         // 14
  data: function () {                                                                                          // 25
    function data() {                                                                                          // 25
      return Tickets.findOne(this.params._id);                                                                 // 26
    }                                                                                                          // 27
                                                                                                               //
    return data;                                                                                               // 25
  }()                                                                                                          // 25
});                                                                                                            // 12
                                                                                                               //
Router.route('/agent/submit/ticket', {                                                                         // 30
  name: 'AgentTicketSubmit',                                                                                   // 31
  waitOn: function () {                                                                                        // 32
    function waitOn() {                                                                                        // 32
      Session.set('hasSidebar', false);                                                                        // 33
      Meteor.subscribe('clientsList');                                                                         // 34
      return Meteor.subscribe('helpTopicsList');                                                               // 35
    }                                                                                                          // 36
                                                                                                               //
    return waitOn;                                                                                             // 32
  }()                                                                                                          // 32
});                                                                                                            // 30
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-client-tickets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-client-tickets.js                                                                         //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Router.route('/tickets', {                                                                                     // 1
  name: 'ticketsHome',                                                                                         // 2
  waitOn: function () {                                                                                        // 3
    function waitOn() {                                                                                        // 3
      Session.set('hasSidebar', false);                                                                        // 4
      Meteor.subscribe('statusList');                                                                          // 5
      Meteor.subscribe('appUsersList');                                                                        // 6
      return Meteor.subscribe('myTicketsAll');                                                                 // 7
    }                                                                                                          // 8
                                                                                                               //
    return waitOn;                                                                                             // 3
  }(),                                                                                                         // 3
  data: function () {                                                                                          // 9
    function data() {}                                                                                         // 9
                                                                                                               //
    return data;                                                                                               // 9
  }()                                                                                                          // 9
});                                                                                                            // 1
                                                                                                               //
Router.route('/search', {                                                                                      // 14
  name: 'search',                                                                                              // 15
  waitOn: function () {                                                                                        // 16
    function waitOn() {                                                                                        // 16
      Session.set('hasSidebar', false);                                                                        // 17
      return Meteor.subscribe('myTicketsSearched', Session.get('searched_subject'));                           // 18
    }                                                                                                          // 19
                                                                                                               //
    return waitOn;                                                                                             // 16
  }()                                                                                                          // 16
});                                                                                                            // 14
                                                                                                               //
Router.route('/ticket/:_id', {                                                                                 // 22
  name: 'ticketPage',                                                                                          // 23
  waitOn: function () {                                                                                        // 24
    function waitOn() {                                                                                        // 24
      Session.set('hasSidebar', true);                                                                         // 25
      Meteor.subscribe('helpTopicsList');                                                                      // 26
      Meteor.subscribe('prioritiesList');                                                                      // 27
      Meteor.subscribe('statusList');                                                                          // 28
      Meteor.subscribe('agentsList');                                                                          // 29
      return Meteor.subscribe('myTicketsAll');                                                                 // 30
    }                                                                                                          // 31
                                                                                                               //
    return waitOn;                                                                                             // 24
  }(),                                                                                                         // 24
  data: function () {                                                                                          // 32
    function data() {                                                                                          // 32
      return Tickets.findOne(this.params._id);                                                                 // 33
    }                                                                                                          // 34
                                                                                                               //
    return data;                                                                                               // 32
  }()                                                                                                          // 32
});                                                                                                            // 22
                                                                                                               //
Router.route('/submit', {                                                                                      // 37
  name: 'ticketSubmit',                                                                                        // 38
  waitOn: function () {                                                                                        // 39
    function waitOn() {                                                                                        // 39
      Session.set('hasSidebar', false);                                                                        // 40
      return Meteor.subscribe('helpTopicsList');                                                               // 41
    }                                                                                                          // 42
                                                                                                               //
    return waitOn;                                                                                             // 39
  }()                                                                                                          // 39
});                                                                                                            // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router-global.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router/router-global.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
                                                                                                               //
Router.configure({                                                                                             // 2
  layoutTemplate: 'layout',                                                                                    // 3
  loadingTemplate: 'loading',                                                                                  // 4
  notFoundTemplate: 'notFound'                                                                                 // 5
  //,waitOn: function () { return Meteor.subscribe('myTicketsAll'); }                                          // 6
});                                                                                                            // 2
                                                                                                               //
Router.route('/', {                                                                                            // 9
  name: 'landingPage',                                                                                         // 10
  waitOn: function () {                                                                                        // 11
    function waitOn() {                                                                                        // 11
      Session.set('hasSidebar', false);                                                                        // 12
    }                                                                                                          // 13
                                                                                                               //
    return waitOn;                                                                                             // 11
  }()                                                                                                          // 11
});                                                                                                            // 9
                                                                                                               //
Router.route('/signup', {                                                                                      // 16
  name: 'registerPage'                                                                                         // 17
});                                                                                                            // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"router.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/router.js                                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
//                                                                                                             // 1
//Router.configure({                                                                                           // 2
//  layoutTemplate: 'layout',                                                                                  // 3
//  loadingTemplate: 'loading',                                                                                // 4
//  notFoundTemplate: 'notFound'                                                                               // 5
//  //,waitOn: function () { return Meteor.subscribe('myTicketsAll'); }                                        // 6
//});                                                                                                          // 7
//                                                                                                             // 8
//Router.route('/', {                                                                                          // 9
//  name: 'ticketsHome',                                                                                       // 10
//  waitOn: function () {                                                                                      // 11
//    return Meteor.subscribe('myTicketsAll');                                                                 // 12
//  },                                                                                                         // 13
//  data: function () {                                                                                        // 14
//                                                                                                             // 15
//  }                                                                                                          // 16
//});                                                                                                          // 17
//                                                                                                             // 18
//Router.route('/admin/users', {                                                                               // 19
//  name: 'usersHome',                                                                                         // 20
//  waitOn: function () {                                                                                      // 21
//    return Meteor.subscribe('usersList');                                                                    // 22
//  },                                                                                                         // 23
//  data: function () {                                                                                        // 24
//                                                                                                             // 25
//  }                                                                                                          // 26
//});                                                                                                          // 27
//                                                                                                             // 28
//Router.route('/admin/appUser/:_id', {                                                                        // 29
//  name: 'adminAppUserView',                                                                                  // 30
//  waitOn: function () {                                                                                      // 31
//    Meteor.subscribe('usersList');                                                                           // 32
//    Meteor.subscribe('userRolesList');                                                                       // 33
//    return Meteor.subscribe('appUsersList');                                                                 // 34
//  },                                                                                                         // 35
//  data: function() {                                                                                         // 36
//    return AppUsers.findOne(this.params._id);                                                                // 37
//  }                                                                                                          // 38
//});                                                                                                          // 39
//                                                                                                             // 40
//Router.route('/signup', {                                                                                    // 41
//  name: 'registerPage'                                                                                       // 42
//});                                                                                                          // 43
//                                                                                                             // 44
//Router.route('/search', {                                                                                    // 45
//  name: 'search',                                                                                            // 46
//  waitOn: function () {                                                                                      // 47
//    return Meteor.subscribe('myTicketsSearched', Session.get('searched_subject'));                           // 48
//  }                                                                                                          // 49
//});                                                                                                          // 50
//                                                                                                             // 51
//Router.route('/ticket/:_id', {                                                                               // 52
//  name: 'ticketPage',                                                                                        // 53
//  waitOn: function () {                                                                                      // 54
//    return Meteor.subscribe('myTicketsAll');                                                                 // 55
//  },                                                                                                         // 56
//  data: function() {                                                                                         // 57
//    return Tickets.findOne(this.params._id);                                                                 // 58
//  }                                                                                                          // 59
//});                                                                                                          // 60
//                                                                                                             // 61
//Router.route('/agent/ticket/:_id', {                                                                         // 62
//  name: 'agentTicketView',                                                                                   // 63
//  waitOn: function () {                                                                                      // 64
//    Meteor.subscribe('helpTopicsList');                                                                      // 65
//    Meteor.subscribe('prioritiesList');                                                                      // 66
//    Meteor.subscribe('statusList');                                                                          // 67
//    Meteor.subscribe('agentsList');                                                                          // 68
//    return Meteor.subscribe('myTicketsAssignedAll');                                                         // 69
//  },                                                                                                         // 70
//  data: function() {                                                                                         // 71
//    return Tickets.findOne(this.params._id);                                                                 // 72
//  }                                                                                                          // 73
//});                                                                                                          // 74
//                                                                                                             // 75
//Router.route('/submit', {name:'ticketSubmit'});                                                              // 76
//                                                                                                             // 77
//var requireLogin = function() {                                                                              // 78
//  if (!Meteor.user()) {                                                                                      // 79
//    this.render('accessDenied');                                                                             // 80
//  } else {                                                                                                   // 81
//    this.next();                                                                                             // 82
//  }                                                                                                          // 83
//}                                                                                                            // 84
//                                                                                                             // 85
//Router.onBeforeAction(requireLogin, {except: 'registerPage'});                                               // 86
////Router.onBeforeAction(requireLogin, {only: 'ticketSubmit'});                                               // 87
//                                                                                                             // 88
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Collections.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/Collections.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});                                        // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"appUsers.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/appUsers.js                                                                                     //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
//var appUser = {                                                                                              // 1
//  userId: 'HShmqa9GhXmr7AR83',                                                                               // 2
//  user_role: 'Admin',                                                                                        // 3
//  department: 'SysAdmin',                                                                                    // 4
//  organization: 'Lomaco',                                                                                    // 5
//  email: 'nicolas.vigier@mycaelis.fr',                                                                       // 6
//  teams: [{}],                                                                                               // 7
//}                                                                                                            // 8
                                                                                                               //
                                                                                                               //
/////////                                                                                                      // 11
/////////                                                                                                      // 12
/////////                                                                                                      // 13
                                                                                                               //
                                                                                                               //
AppUsers = new Mongo.Collection('appusers');                                                                   // 16
                                                                                                               //
AppUsers.allow({                                                                                               // 19
  insert: function () {                                                                                        // 20
    function insert(userId, doc) {                                                                             // 20
      return !!userId;                                                                                         // 21
    }                                                                                                          // 22
                                                                                                               //
    return insert;                                                                                             // 20
  }()                                                                                                          // 20
});                                                                                                            // 19
                                                                                                               //
Meteor.methods({                                                                                               // 26
  appUserInsert: function () {                                                                                 // 27
    function appUserInsert(appUserAttributes) {                                                                // 27
      //check(appUserAttributes, {                                                                             // 28
      //  userId: String,                                                                                      // 29
      //  user_role: String,                                                                                   // 30
      //  department: String,                                                                                  // 31
      //  teams: Array,                                                                                        // 32
      //});                                                                                                    // 33
                                                                                                               //
      var appUser = _.extend(appUserAttributes, {                                                              // 35
        userId: Meteor.userId(),                                                                               // 36
        created_at: new Date(),                                                                                // 37
        updated_at: new Date()                                                                                 // 38
      });                                                                                                      // 35
                                                                                                               //
      var appUserId = AppUsers.insert(appUser);                                                                // 41
                                                                                                               //
      return {                                                                                                 // 43
        _id: appUserId                                                                                         // 44
      };                                                                                                       // 43
    }                                                                                                          // 46
                                                                                                               //
    return appUserInsert;                                                                                      // 27
  }(),                                                                                                         // 27
  appUserUpdate: function () {                                                                                 // 47
    function appUserUpdate(appUserAttributes) {                                                                // 47
      check(Meteor.userId(), String);                                                                          // 48
                                                                                                               //
      appUserAttributes.updated_at = new Date();                                                               // 50
                                                                                                               //
      if (_.has(appUserAttributes, 'oldEmail')) {                                                              // 52
        var user = Accounts.findUserByEmail(appUserAttributes.oldEmail);                                       // 53
        Accounts.addEmail(user._id, appUserAttributes.email, true);                                            // 54
        Accounts.removeEmail(user._id, appUserAttributes.oldEmail);                                            // 55
        appUserAttributes = _.omit(appUserAttributes, 'oldEmail');                                             // 56
      }                                                                                                        // 57
                                                                                                               //
      var appUserId = AppUsers.update(appUserAttributes._id, appUserAttributes);                               // 59
                                                                                                               //
      return {                                                                                                 // 61
        _id: appUserId                                                                                         // 62
      };                                                                                                       // 61
    }                                                                                                          // 64
                                                                                                               //
    return appUserUpdate;                                                                                      // 47
  }(),                                                                                                         // 47
  agentAddTeam: function () {                                                                                  // 65
    function agentAddTeam(params) {                                                                            // 65
      check(Meteor.userId(), String);                                                                          // 66
                                                                                                               //
      AppUsers.update({ _id: params.agentId }, { $addToSet: { teamsId: params.teamId } });                     // 68
    }                                                                                                          // 69
                                                                                                               //
    return agentAddTeam;                                                                                       // 65
  }(),                                                                                                         // 65
  agentRemoveTeam: function () {                                                                               // 70
    function agentRemoveTeam(params) {                                                                         // 70
      check(Meteor.userId(), String);                                                                          // 71
                                                                                                               //
      AppUsers.update({ _id: params.agentId }, { $pull: { teamsId: params.teamId } });                         // 73
    }                                                                                                          // 74
                                                                                                               //
    return agentRemoveTeam;                                                                                    // 70
  }(),                                                                                                         // 70
  appUserUpdateUpdatedAt: function () {                                                                        // 75
    function appUserUpdateUpdatedAt(appUserId) {                                                               // 75
      check(appUserId, String);                                                                                // 76
      AppUsers.update({ _id: appUserId }, { $set: { updated_at: new Date() } });                               // 77
      return { _id: appUserId };                                                                               // 78
    }                                                                                                          // 79
                                                                                                               //
    return appUserUpdateUpdatedAt;                                                                             // 75
  }()                                                                                                          // 75
                                                                                                               //
});                                                                                                            // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"contracts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/contracts.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Contracts = new Mongo.Collection('contracts');                                                                 // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"departments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/departments.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Departments = new Mongo.Collection('departments');                                                             // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"helpTopics.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/helpTopics.js                                                                                   //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
HelpTopics = new Mongo.Collection('helptopics');                                                               // 1
                                                                                                               //
/*                                                                                                             // 3
label: String                                                                                                  //
teamId: teamId                                                                                                 //
*/                                                                                                             //
                                                                                                               //
HelpTopics.allow({                                                                                             // 9
  insert: function () {                                                                                        // 10
    function insert(userId, doc) {                                                                             // 10
      return !!userId;                                                                                         // 11
    }                                                                                                          // 12
                                                                                                               //
    return insert;                                                                                             // 10
  }()                                                                                                          // 10
});                                                                                                            // 9
                                                                                                               //
Meteor.methods({                                                                                               // 15
  helpTopicInsert: function () {                                                                               // 16
    function helpTopicInsert(item) {                                                                           // 16
      check(Meteor.userId(), String);                                                                          // 17
                                                                                                               //
      var helpTopicId = HelpTopics.insert(item);                                                               // 19
                                                                                                               //
      return {                                                                                                 // 21
        _id: helpTopicId                                                                                       // 22
      };                                                                                                       // 21
    }                                                                                                          // 24
                                                                                                               //
    return helpTopicInsert;                                                                                    // 16
  }(),                                                                                                         // 16
  helpTopicUpdate: function () {                                                                               // 25
    function helpTopicUpdate(item) {                                                                           // 25
      check(Meteor.userId(), String);                                                                          // 26
                                                                                                               //
      var helpTopicId = HelpTopics.update(item._id, item);                                                     // 28
                                                                                                               //
      return {                                                                                                 // 30
        _id: helpTopicId                                                                                       // 31
      };                                                                                                       // 30
    }                                                                                                          // 33
                                                                                                               //
    return helpTopicUpdate;                                                                                    // 25
  }()                                                                                                          // 25
});                                                                                                            // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"organizations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/organizations.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Organizations = new Mongo.Collection('organizations');                                                         // 1
                                                                                                               //
/*                                                                                                             // 3
name: String                                                                                                   //
code: String                                                                                                   //
address: obj                                                                                                   //
  rue, ville, CP                                                                                               //
observateurs: [AppUsersId]                                                                                     //
org_parent: OrganizationsId                                                                                    //
*/                                                                                                             //
                                                                                                               //
Organizations.allow({                                                                                          // 12
  insert: function () {                                                                                        // 13
    function insert(userId, doc) {                                                                             // 13
      return !!userId;                                                                                         // 14
    }                                                                                                          // 15
                                                                                                               //
    return insert;                                                                                             // 13
  }()                                                                                                          // 13
});                                                                                                            // 12
                                                                                                               //
Meteor.methods({                                                                                               // 18
  organizationInsert: function () {                                                                            // 19
    function organizationInsert(orgAttributes) {                                                               // 19
      check(Meteor.userId(), String);                                                                          // 20
                                                                                                               //
      var organization = _.extend(orgAttributes, {                                                             // 22
        created_at: new Date(),                                                                                // 23
        updated_at: new Date()                                                                                 // 24
      });                                                                                                      // 22
                                                                                                               //
      var organizationId = Organizations.insert(organization);                                                 // 27
                                                                                                               //
      return {                                                                                                 // 29
        _id: organizationId                                                                                    // 30
      };                                                                                                       // 29
    }                                                                                                          // 32
                                                                                                               //
    return organizationInsert;                                                                                 // 19
  }(),                                                                                                         // 19
  organizationUpdate: function () {                                                                            // 33
    function organizationUpdate(organizationAttributes) {                                                      // 33
      check(Meteor.userId(), String);                                                                          // 34
      //check(ticketAttributes, {                                                                              // 35
      //  subject: String,                                                                                     // 36
      //  message: String,                                                                                     // 37
      //  author: String,                                                                                      // 38
      //});                                                                                                    // 39
                                                                                                               //
      organizationAttributes.updated_at = new Date();                                                          // 41
                                                                                                               //
      var organizationId = Organizations.update(organizationAttributes._id, organizationAttributes);           // 43
                                                                                                               //
      return {                                                                                                 // 45
        _id: organizationId                                                                                    // 46
      };                                                                                                       // 45
    }                                                                                                          // 48
                                                                                                               //
    return organizationUpdate;                                                                                 // 33
  }()                                                                                                          // 33
});                                                                                                            // 18
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"priorities.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/priorities.js                                                                                   //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Priorities = new Mongo.Collection('priorities');                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"replies.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/replies.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Replies = new Mongo.Collection('replies');                                                                     // 1
                                                                                                               //
/*                                                                                                             // 3
ticketId: String                                                                                               //
author: String                                                                                                 //
type: Réponse, Suivi, Tâche, Solution, Note                                                                    //
is_private: bool                                                                                               //
posted_at: Date                                                                                                //
content: String                                                                                                //
attached: Object                                                                                               //
                                                                                                               //
                                                                                                               //
*/                                                                                                             //
                                                                                                               //
Replies.allow({                                                                                                // 15
  insert: function () {                                                                                        // 16
    function insert(userId, doc) {                                                                             // 16
      return !!userId;                                                                                         // 17
    }                                                                                                          // 18
                                                                                                               //
    return insert;                                                                                             // 16
  }()                                                                                                          // 16
});                                                                                                            // 15
                                                                                                               //
Meteor.methods({                                                                                               // 22
  replyInsert: function () {                                                                                   // 23
    function replyInsert(replyAttributes) {                                                                    // 23
                                                                                                               //
      var user = Meteor.user();                                                                                // 25
      var reply = _.extend(replyAttributes, {                                                                  // 26
        userId: user._id,                                                                                      // 27
        posted_at: new Date(),                                                                                 // 28
        author: user.profile.fullName                                                                          // 29
      });                                                                                                      // 26
                                                                                                               //
      var ticketId = reply.ticketId;                                                                           // 32
                                                                                                               //
      var replyId = Replies.insert(reply);                                                                     // 34
                                                                                                               //
      //TODO: update_date ticket                                                                               // 36
      Meteor.call('ticketUpdateUpdatedAt', ticketId);                                                          // 37
                                                                                                               //
      return {                                                                                                 // 39
        _id: replyId                                                                                           // 40
      };                                                                                                       // 39
    }                                                                                                          // 42
                                                                                                               //
    return replyInsert;                                                                                        // 23
  }(),                                                                                                         // 23
  deleteReply: function () {                                                                                   // 43
    function deleteReply(replyAttributes) {                                                                    // 43
      check(replyAttributes, {                                                                                 // 44
        id: String,                                                                                            // 45
        userId: String                                                                                         // 46
      });                                                                                                      // 44
                                                                                                               //
      Replies.remove({ _id: replyAttributes.id });                                                             // 49
    }                                                                                                          // 50
                                                                                                               //
    return deleteReply;                                                                                        // 43
  }()                                                                                                          // 43
                                                                                                               //
});                                                                                                            // 22
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"replyTypes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/replyTypes.js                                                                                   //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
ReplyTypes = new Mongo.Collection('replytypes');                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"softwares.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/softwares.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Softwares = new Mongo.Collection('softwares');                                                                 // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"status.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/status.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Status = new Mongo.Collection('status');                                                                       // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"teams.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/teams.js                                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Teams = new Mongo.Collection('teams');                                                                         // 1
                                                                                                               //
/*                                                                                                             // 3
name: String                                                                                                   //
agentsId: [AppUsersId]                                                                                         //
responsablesId: [AppUsersId]                                                                                   //
agentsId: [AppUsersId]                                                                                         //
globalTeamId: TeamId                                                                                           //
*/                                                                                                             //
                                                                                                               //
Teams.allow({                                                                                                  // 12
  insert: function () {                                                                                        // 13
    function insert(userId, doc) {                                                                             // 13
      return !!userId;                                                                                         // 14
    }                                                                                                          // 15
                                                                                                               //
    return insert;                                                                                             // 13
  }()                                                                                                          // 13
});                                                                                                            // 12
                                                                                                               //
Meteor.methods({                                                                                               // 18
  teamInsert: function () {                                                                                    // 19
    function teamInsert(item) {                                                                                // 19
      check(Meteor.userId(), String);                                                                          // 20
                                                                                                               //
      var team = _.extend(item, {                                                                              // 22
        created_at: new Date(),                                                                                // 23
        updated_at: new Date()                                                                                 // 24
      });                                                                                                      // 22
                                                                                                               //
      var teamId = Teams.insert(team);                                                                         // 27
                                                                                                               //
      return {                                                                                                 // 29
        _id: teamId                                                                                            // 30
      };                                                                                                       // 29
    }                                                                                                          // 32
                                                                                                               //
    return teamInsert;                                                                                         // 19
  }(),                                                                                                         // 19
  teamUpdate: function () {                                                                                    // 33
    function teamUpdate(item) {                                                                                // 33
      check(Meteor.userId(), String);                                                                          // 34
                                                                                                               //
      item.updated_at = new Date();                                                                            // 36
                                                                                                               //
      var teamId = Teams.update(item._id, item);                                                               // 38
                                                                                                               //
      return {                                                                                                 // 40
        _id: teamId                                                                                            // 41
      };                                                                                                       // 40
    }                                                                                                          // 43
                                                                                                               //
    return teamUpdate;                                                                                         // 33
  }()                                                                                                          // 33
});                                                                                                            // 18
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tickets.js":["meteor/email",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/tickets.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Email;module.import('meteor/email',{"Email":function(v){Email=v}});                                        // 1
                                                                                                               //
Tickets = new Mongo.Collection('tickets');                                                                     // 3
                                                                                                               //
Tickets.allow({                                                                                                // 6
  insert: function () {                                                                                        // 7
    function insert(userId, doc) {                                                                             // 7
      return !!userId;                                                                                         // 8
    }                                                                                                          // 9
                                                                                                               //
    return insert;                                                                                             // 7
  }()                                                                                                          // 7
});                                                                                                            // 6
                                                                                                               //
Meteor.methods({                                                                                               // 13
  ticketInsert: function () {                                                                                  // 14
    function ticketInsert(ticketAttributes) {                                                                  // 14
      check(Meteor.userId(), String);                                                                          // 15
      check(ticketAttributes, {                                                                                // 16
        subject: String,                                                                                       // 17
        message: String,                                                                                       // 18
        help_topic: String                                                                                     // 19
      });                                                                                                      // 16
                                                                                                               //
      //var user = Meteor.user();                                                                              // 22
      var user = AppUsers.findOne({ userId: Meteor.userId() });                                                // 23
                                                                                                               //
      var helpTopic = HelpTopics.findOne({ label: ticketAttributes.help_topic }, { fields: { teamId: 1 } });   // 25
                                                                                                               //
      var toAssignedPool = Teams.findOne({ _id: helpTopic.teamId }, { fields: { agentsId: 1 } });              // 27
                                                                                                               //
      if (!toAssignedPool) {                                                                                   // 29
        var toAssignedPool = { agentsId: [] };                                                                 // 30
      }                                                                                                        // 31
                                                                                                               //
      var ticket = _.extend(ticketAttributes, {                                                                // 33
        userId: user.userId,                                                                                   // 34
        created_at: new Date(),                                                                                // 35
        updated_at: new Date(),                                                                                // 36
        status: "Nouveau",                                                                                     // 37
        priority: "Moyenne",                                                                                   // 38
        severity: "Moyen",                                                                                     // 39
        requesterId: user._id,                                                                                 // 40
        closed: false,                                                                                         // 41
        is_assigned: false,                                                                                    // 42
        last_message: user.fullName,                                                                           // 43
        agents: toAssignedPool.agentsId,                                                                       // 44
        author: user.fullName                                                                                  // 45
      });                                                                                                      // 33
                                                                                                               //
      var ticketId = Tickets.insert(ticket);                                                                   // 48
                                                                                                               //
      //Envoi mail au créateur                                                                                 // 51
      var html_creator = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	<title>Notification de nouveau ticket au Support Lomaco</title></head><body></body></html>';
                                                                                                               //
      var email_options_creator = {                                                                            // 55
        from: "Support Lomaco <support.admins@mycaelis.fr>",                                                   // 56
        to: user.email,                                                                                        // 57
        subject: "Notification de nouveau ticket au Support Lomaco",                                           // 58
        text: 'Status: ' + ticket.status + '\nRequête: ' + ticket.help_topic + '\n\nSujet: ' + ticket.subject + '\n\nMessage: ' + ticket.message + '\n\nCordialement,\nLe support Lomaco.'
      };                                                                                                       // 55
                                                                                                               //
      //    Email.send(email_options_creator);                                                                 // 62
                                                                                                               //
      //Envoi mail au responsable d'agence                                                                     // 64
      var html_resp_agence = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	<title>Notification de nouveau ticket au Support Lomaco</title></head><body></body></html>';
                                                                                                               //
      var agency = Organizations.findOne({ code: user.organization });                                         // 68
                                                                                                               //
      var resp = AppUsers.findOne(agency.responsableId);                                                       // 70
                                                                                                               //
      if (resp.email) {                                                                                        // 72
        var email_options_resp_agence = {                                                                      // 73
          from: "Support Lomaco <support.admins@mycaelis.fr>",                                                 // 74
          to: resp.email,                                                                                      // 75
          subject: "Notification de nouveau ticket au Support Lomaco",                                         // 76
          text: 'Bonjour,\nVous recevez ce mail car le propriétaire de  l\'adresse "' + resp.email + '" est renseignée comme observateur de ce ticket.' + '\n\nStatus: ' + ticket.status + '\nRequête: ' + ticket.help_topic + '\n\nSujet: ' + ticket.subject + '\n\nMessage: ' + ticket.message + '\n\nCordialement,\nLe support Lomaco.'
        };                                                                                                     // 73
                                                                                                               //
        console.log(email_options_resp_agence);                                                                // 85
        //Email.send(email_options_resp_agence);                                                               // 86
      }                                                                                                        // 88
                                                                                                               //
      if (agency.org_parent) {                                                                                 // 90
                                                                                                               //
        //Envoi mail au responsable d'organisation                                                             // 92
        var html_resp_org = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	<title>Notification de nouveau ticket au Support Lomaco</title></head><body></body></html>';
                                                                                                               //
        var organization = Organizations.findOne(agency.org_parentId);                                         // 96
                                                                                                               //
        var orgResp = AppUsers.findOne({ organization: organization.code });                                   // 98
                                                                                                               //
        if (orgResp.email) {                                                                                   // 100
          var email_options_resp_org = {                                                                       // 101
            from: "Support Lomaco <support.admins@mycaelis.fr>",                                               // 102
            to: orgResp.email,                                                                                 // 103
            subject: "Notification de nouveau ticket au Support Lomaco",                                       // 104
            text: 'Bonjour,\nVous recevez ce mail car le propriétaire de  l\'adresse "' + orgResp.email + '" est renseignée comme observateur de ce ticket.' + '\n\nStatus: ' + ticket.status + '\nRequête: ' + ticket.help_topic + '\n\nSujet: ' + ticket.subject + '\n\nMessage: ' + ticket.message + '\n\nCordialement,\nLe support Lomaco.'
          };                                                                                                   // 101
                                                                                                               //
          console.log(email_options_resp_org);                                                                 // 113
                                                                                                               //
          //    Email.send(email_options_resp_agence);                                                         // 115
        }                                                                                                      // 116
      }                                                                                                        // 117
                                                                                                               //
      return {                                                                                                 // 119
        _id: ticketId                                                                                          // 120
      };                                                                                                       // 119
    }                                                                                                          // 122
                                                                                                               //
    return ticketInsert;                                                                                       // 14
  }(),                                                                                                         // 14
  agentTicketInsert: function () {                                                                             // 123
    function agentTicketInsert(ticketAttributes) {                                                             // 123
      check(Meteor.userId(), String);                                                                          // 124
                                                                                                               //
      var helpTopic = HelpTopics.findOne({ label: ticketAttributes.help_topic }, { fields: { teamId: 1 } });   // 126
                                                                                                               //
      var toAssignedPool = Teams.findOne({ _id: helpTopic.teamId }, { fields: { agentsId: 1 } });              // 128
                                                                                                               //
      var requester = AppUsers.findOne(ticketAttributes.requesterId);                                          // 130
                                                                                                               //
      var ticket = _.extend(ticketAttributes, {                                                                // 132
        userId: requester.userId,                                                                              // 133
        author: requester.fullName,                                                                            // 134
        created_at: new Date(),                                                                                // 135
        updated_at: new Date(),                                                                                // 136
        status: "Nouveau",                                                                                     // 137
        priority: "Moyenne",                                                                                   // 138
        severity: "Moyen",                                                                                     // 139
        closed: false,                                                                                         // 140
        is_assigned: false,                                                                                    // 141
        agents: toAssignedPool.agentsId                                                                        // 142
      });                                                                                                      // 132
                                                                                                               //
      var ticketId = Tickets.insert(ticket);                                                                   // 145
                                                                                                               //
      //Envoi mail au responsable d'agence                                                                     // 149
      var html_resp_agence = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	<title>Notification de nouveau ticket au Support Lomaco</title></head><body></body></html>';
                                                                                                               //
      var agency = Organizations.findOne({ code: requester.organization });                                    // 153
                                                                                                               //
      var resp = AppUsers.findOne(agency.responsableId);                                                       // 155
                                                                                                               //
      if (resp) {                                                                                              // 157
        var email_options_resp_agence = {                                                                      // 158
          from: "Support Lomaco <support.admins@mycaelis.fr>",                                                 // 159
          to: resp.email,                                                                                      // 160
          subject: "Notification de nouveau ticket au Support Lomaco",                                         // 161
          text: 'Bonjour,\nVous recevez ce mail car le propriétaire de  l\'adresse "' + resp.email + '" est renseignée comme observateur de ce ticket.' + '\n\nStatus: ' + ticket.status + '\nRequête: ' + ticket.help_topic + '\n\nSujet: ' + ticket.subject + '\n\nMessage: ' + ticket.message + '\n\nCordialement,\nLe support Lomaco.'
        };                                                                                                     // 158
                                                                                                               //
        console.log(email_options_resp_agence);                                                                // 170
        //    Email.send(email_options_resp_agence);                                                           // 171
      }                                                                                                        // 173
                                                                                                               //
      if (agency.org_parent) {                                                                                 // 175
                                                                                                               //
        //Envoi mail au responsable d'organisation                                                             // 177
        var html_resp_org = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>	<title>Notification de nouveau ticket au Support Lomaco</title></head><body></body></html>';
                                                                                                               //
        var organization = agency.org_parent;                                                                  // 181
                                                                                                               //
        var orgResp = AppUsers.findOne(organization.responsableId);                                            // 183
                                                                                                               //
        if (orgResp) {                                                                                         // 185
          var email_options_resp_org = {                                                                       // 186
            from: "Support Lomaco <support.admins@mycaelis.fr>",                                               // 187
            to: orgResp.email,                                                                                 // 188
            subject: "Notification de nouveau ticket au Support Lomaco",                                       // 189
            text: 'Bonjour,\nVous recevez ce mail car le propriétaire de  l\'adresse "' + orgResp.email + '" est renseignée comme observateur de ce ticket.' + '\n\nStatus: ' + ticket.status + '\nRequête: ' + ticket.help_topic + '\n\nSujet: ' + ticket.subject + '\n\nMessage: ' + ticket.message + '\n\nCordialement,\nLe support Lomaco.'
          };                                                                                                   // 186
                                                                                                               //
          console.log(email_options_resp_org);                                                                 // 198
                                                                                                               //
          //    Email.send(email_options_resp_agence);                                                         // 200
        }                                                                                                      // 201
      }                                                                                                        // 202
                                                                                                               //
      return {                                                                                                 // 204
        _id: ticketId                                                                                          // 205
      };                                                                                                       // 204
    }                                                                                                          // 207
                                                                                                               //
    return agentTicketInsert;                                                                                  // 123
  }(),                                                                                                         // 123
  deleteTicket: function () {                                                                                  // 208
    function deleteTicket(ticketAttributes) {                                                                  // 208
      check(ticketAttributes, {                                                                                // 209
        id: String,                                                                                            // 210
        userId: String                                                                                         // 211
      });                                                                                                      // 209
                                                                                                               //
      Tickets.remove({ _id: ticketAttributes.id });                                                            // 214
    }                                                                                                          // 215
                                                                                                               //
    return deleteTicket;                                                                                       // 208
  }(),                                                                                                         // 208
  ticketUpdate: function () {                                                                                  // 216
    function ticketUpdate(ticketAttributes) {                                                                  // 216
      console.log(ticketAttributes);                                                                           // 217
      check(Meteor.userId(), String);                                                                          // 218
                                                                                                               //
      var user = AppUsers.findOne(Meteor.userId());                                                            // 220
      ticketAttributes.updated_at = new Date();                                                                // 221
                                                                                                               //
      if (ticketAttributes.agents == null) {                                                                   // 223
        ticketAttributes.agents = [];                                                                          // 224
      }                                                                                                        // 225
      ////                                                                                                     // 226
                                                                                                               //
                                                                                                               //
      if (ticketAttributes.help_topic != "") {                                                                 // 229
        var helpTopic = HelpTopics.findOne({ label: ticketAttributes.help_topic }, { fields: { teamId: 1 } });
                                                                                                               //
        var toAssignedPool = Teams.findOne({ _id: helpTopic.teamId }, { fields: { agentsId: 1 } });            // 233
                                                                                                               //
        console.log(ticketAttributes.agents);                                                                  // 235
                                                                                                               //
        if (toAssignedPool) {                                                                                  // 237
          if (ticketAttributes.agents == []) {                                                                 // 238
            ticketAttributes.agents = _.intersection(ticketAttributes.agents, toAssignedPool.agentsId);        // 239
          } else {                                                                                             // 240
            ticketAttributes.agents = _.union(ticketAttributes.agents, toAssignedPool.agentsId);               // 241
          }                                                                                                    // 242
        }                                                                                                      // 243
      }                                                                                                        // 244
      ////                                                                                                     // 245
                                                                                                               //
      var ticketId = Tickets.update(ticketAttributes._id, ticketAttributes);                                   // 247
                                                                                                               //
      return {                                                                                                 // 249
        _id: ticketId                                                                                          // 250
      };                                                                                                       // 249
    }                                                                                                          // 252
                                                                                                               //
    return ticketUpdate;                                                                                       // 216
  }(),                                                                                                         // 216
  ticketUpdateUpdatedAt: function () {                                                                         // 253
    function ticketUpdateUpdatedAt(ticketId) {                                                                 // 253
      check(ticketId, String);                                                                                 // 254
      Tickets.update({ _id: ticketId }, { $set: { updated_at: new Date() } });                                 // 255
      return { _id: ticketId };                                                                                // 256
    }                                                                                                          // 257
                                                                                                               //
    return ticketUpdateUpdatedAt;                                                                              // 253
  }()                                                                                                          // 253
                                                                                                               //
});                                                                                                            // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"userRole.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/userRole.js                                                                                     //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
UserRoles = new Mongo.Collection('userroles');                                                                 // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"userRoles.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// collections/userRoles.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
//UserRoles = new Mongo.Collection('userroles');                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixtures.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/fixtures.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
if (Status.find().count() === 0) {                                                                             // 1
  Status.insert({                                                                                              // 2
    label: "Tous mes tickets",                                                                                 // 3
    labelColor: "red accent-4",                                                                                // 4
    sidebarLabelColor: "",                                                                                     // 5
    code: "all"                                                                                                // 6
  });                                                                                                          // 2
                                                                                                               //
  Status.insert({                                                                                              // 9
    label: "Nouveaux",                                                                                         // 10
    labelColor: "light-blue darken-4",                                                                         // 11
    sidebarLabelColor: "light-blue-text text-lighten-1",                                                       // 12
    code: "Nouveau"                                                                                            // 13
  });                                                                                                          // 9
                                                                                                               //
  Status.insert({                                                                                              // 16
    label: "En cours",                                                                                         // 17
    labelColor: "amber darken-1",                                                                              // 18
    sidebarLabelColor: "amber-text",                                                                           // 19
    code: "En cours"                                                                                           // 20
  });                                                                                                          // 16
                                                                                                               //
  Status.insert({                                                                                              // 23
    label: "En attente",                                                                                       // 24
    labelColor: "orange darken-4",                                                                             // 25
    sidebarLabelColor: "orange-text text-darken-3",                                                            // 26
    code: "En attente"                                                                                         // 27
  });                                                                                                          // 23
                                                                                                               //
  Status.insert({                                                                                              // 30
    label: "Résolus",                                                                                          // 31
    labelColor: "green",                                                                                       // 32
    sidebarLabelColor: "green-text",                                                                           // 33
    code: "Résolu"                                                                                             // 34
  });                                                                                                          // 30
                                                                                                               //
  Status.insert({                                                                                              // 37
    label: "Clos",                                                                                             // 38
    labelColor: "grey",                                                                                        // 39
    sidebarLabelColor: "blue-grey-text text-lighten-3",                                                        // 40
    code: "Clos"                                                                                               // 41
  });                                                                                                          // 37
}                                                                                                              // 43
                                                                                                               //
if (UserRoles.find().count() === 0) {                                                                          // 45
  UserRoles.insert({                                                                                           // 46
    label: "Admin",                                                                                            // 47
    labelColor: "red accent-4",                                                                                // 48
    code: "Admin"                                                                                              // 49
  });                                                                                                          // 46
                                                                                                               //
  UserRoles.insert({                                                                                           // 52
    label: "Agent",                                                                                            // 53
    labelColor: "light-blue darken-4",                                                                         // 54
    code: "Agent"                                                                                              // 55
  });                                                                                                          // 52
                                                                                                               //
  UserRoles.insert({                                                                                           // 58
    label: "Client",                                                                                           // 59
    labelColor: "amber darken-1",                                                                              // 60
    code: "Client"                                                                                             // 61
  });                                                                                                          // 58
}                                                                                                              // 63
                                                                                                               //
if (ReplyTypes.find().count() === 0) {                                                                         // 65
  ReplyTypes.insert({                                                                                          // 66
    //Réponse, Suivi, Tâche, Solution, Note                                                                    // 67
    label: "Message",                                                                                          // 68
    labelColor: "black-text",                                                                                  // 69
    bgColor: "grey lighten-5"                                                                                  // 70
  });                                                                                                          // 66
                                                                                                               //
  ReplyTypes.insert({                                                                                          // 73
    label: "Suivi",                                                                                            // 74
    labelColor: "black-text",                                                                                  // 75
    bgColor: "blue lighten-5"                                                                                  // 76
  });                                                                                                          // 73
                                                                                                               //
  ReplyTypes.insert({                                                                                          // 79
    label: "Tâche",                                                                                            // 80
    labelColor: "black-text",                                                                                  // 81
    bgColor: "amber lighten-5"                                                                                 // 82
  });                                                                                                          // 79
                                                                                                               //
  ReplyTypes.insert({                                                                                          // 85
    label: "Solution",                                                                                         // 86
    labelColor: "black-text",                                                                                  // 87
    bgColor: "green lighten-5"                                                                                 // 88
  });                                                                                                          // 85
                                                                                                               //
  ReplyTypes.insert({                                                                                          // 91
    label: "Réponse",                                                                                          // 92
    labelColor: "black-text",                                                                                  // 93
    bgColor: "red lighten-5"                                                                                   // 94
  });                                                                                                          // 91
}                                                                                                              // 97
                                                                                                               //
if (HelpTopics.find().count() === 0) {                                                                         // 99
  HelpTopics.insert({                                                                                          // 100
    label: "Général"                                                                                           // 101
  });                                                                                                          // 100
                                                                                                               //
  HelpTopics.insert({                                                                                          // 104
    label: "Horizon"                                                                                           // 105
  });                                                                                                          // 104
                                                                                                               //
  HelpTopics.insert({                                                                                          // 108
    label: "Osiris"                                                                                            // 109
  });                                                                                                          // 108
}                                                                                                              // 111
                                                                                                               //
if (Priorities.find().count() === 0) {                                                                         // 113
  Priorities.insert({                                                                                          // 114
    label: "Très haute"                                                                                        // 115
  });                                                                                                          // 114
                                                                                                               //
  Priorities.insert({                                                                                          // 118
    label: "Haute"                                                                                             // 119
  });                                                                                                          // 118
                                                                                                               //
  Priorities.insert({                                                                                          // 122
    label: "Moyenne"                                                                                           // 123
  });                                                                                                          // 122
                                                                                                               //
  Priorities.insert({                                                                                          // 126
    label: "Basse"                                                                                             // 127
  });                                                                                                          // 126
                                                                                                               //
  Priorities.insert({                                                                                          // 130
    label: "Très basse"                                                                                        // 131
  });                                                                                                          // 130
}                                                                                                              // 134
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/publish.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.publish('repliesList', function (ticket_id) {                                                           // 1
  return Replies.find({ ticketId: ticket_id });                                                                // 2
});                                                                                                            // 3
                                                                                                               //
Meteor.publish('replyTypesList', function () {                                                                 // 5
  return ReplyTypes.find();                                                                                    // 6
});                                                                                                            // 7
                                                                                                               //
Meteor.publish('statusList', function () {                                                                     // 9
  return Status.find();                                                                                        // 10
});                                                                                                            // 11
                                                                                                               //
Meteor.publish('userRolesList', function () {                                                                  // 13
  return UserRoles.find();                                                                                     // 14
});                                                                                                            // 15
                                                                                                               //
Meteor.publish('appUsersList', function () {                                                                   // 18
  return AppUsers.find();                                                                                      // 19
});                                                                                                            // 20
                                                                                                               //
Meteor.publish('appUsersRoleList', function (role) {                                                           // 22
  return AppUsers.find({ user_role: role });                                                                   // 23
});                                                                                                            // 24
                                                                                                               //
Meteor.publish('agentsList', function () {                                                                     // 26
  return AppUsers.find({ user_role: { $ne: 'Client' } });                                                      // 27
});                                                                                                            // 28
                                                                                                               //
Meteor.publish('clientsList', function () {                                                                    // 30
  return AppUsers.find({ user_role: 'Client' });                                                               // 31
});                                                                                                            // 32
                                                                                                               //
Meteor.publish('responsiblesList', function () {                                                               // 34
  return AppUsers.find({ is_observer: true });                                                                 // 35
});                                                                                                            // 36
                                                                                                               //
Meteor.publish('usersList', function () {                                                                      // 41
  return Meteor.users.find();                                                                                  // 42
});                                                                                                            // 43
                                                                                                               //
Meteor.publish('helpTopicsList', function () {                                                                 // 45
  return HelpTopics.find();                                                                                    // 46
});                                                                                                            // 47
                                                                                                               //
Meteor.publish('prioritiesList', function () {                                                                 // 49
  return Priorities.find();                                                                                    // 50
});                                                                                                            // 51
                                                                                                               //
Meteor.publish('organizationsList', function () {                                                              // 53
  return Organizations.find();                                                                                 // 54
});                                                                                                            // 55
                                                                                                               //
Meteor.publish('organizationItem', function (_id) {                                                            // 57
  return Organizations.find(_id);                                                                              // 58
});                                                                                                            // 59
                                                                                                               //
Meteor.publish('teamsList', function () {                                                                      // 61
  return Teams.find();                                                                                         // 62
});                                                                                                            // 63
                                                                                                               //
Meteor.publish('teamItem', function (_id) {                                                                    // 65
  return Teams.find(_id);                                                                                      // 66
});                                                                                                            // 67
                                                                                                               //
Meteor.publish('myTicketsAll', function () {                                                                   // 70
  if (this.userId) {                                                                                           // 71
    var appUser = AppUsers.findOne({ userId: this.userId });                                                   // 72
    return Tickets.find({ userId: appUser.userId });                                                           // 73
  }                                                                                                            // 74
  return null;                                                                                                 // 75
});                                                                                                            // 76
                                                                                                               //
Meteor.publish('myTicketsAssignedAll', function () {                                                           // 78
  var agent = AppUsers.findOne({ userId: this.userId });                                                       // 79
  if (agent.user_role == 'Agent') {                                                                            // 80
    return Tickets.find({                                                                                      // 81
      agents: {                                                                                                // 82
        $in: [agent._id, '', null, []]                                                                         // 83
      }                                                                                                        // 82
    });                                                                                                        // 81
  }                                                                                                            // 86
  return Tickets.find();                                                                                       // 87
});                                                                                                            // 88
                                                                                                               //
Meteor.publish('myTicketsSearched', function (search) {                                                        // 90
  var query = {},                                                                                              // 91
      projection = { limit: 10, sort: { updated_at: 1 } };                                                     // 91
                                                                                                               //
  if (search) {                                                                                                // 94
    var regex = new RegExp(search, 'i');                                                                       // 95
                                                                                                               //
    query = { $and: [{ subject: regex }, { userId: this.userId }] };                                           // 97
                                                                                                               //
    projection.limit = 100;                                                                                    // 102
  }                                                                                                            // 103
                                                                                                               //
  return Tickets.find(query, projection);                                                                      // 105
});                                                                                                            // 106
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                    // 1
                                                                                                               //
Meteor.startup(function () {                                                                                   // 3
  // code to run on server at startup                                                                          // 4
});                                                                                                            // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/methods/agents-methods.js");
require("./lib/methods/users-methods.js");
require("./lib/router/acl.js");
require("./lib/router/router-admin-global.js");
require("./lib/router/router-admin-helpTopics.js");
require("./lib/router/router-admin-organizations.js");
require("./lib/router/router-admin-teams.js");
require("./lib/router/router-admin-users.js");
require("./lib/router/router-agent-tickets.js");
require("./lib/router/router-client-tickets.js");
require("./lib/router/router-global.js");
require("./lib/router.js");
require("./collections/Collections.js");
require("./collections/appUsers.js");
require("./collections/contracts.js");
require("./collections/departments.js");
require("./collections/helpTopics.js");
require("./collections/organizations.js");
require("./collections/priorities.js");
require("./collections/replies.js");
require("./collections/replyTypes.js");
require("./collections/softwares.js");
require("./collections/status.js");
require("./collections/teams.js");
require("./collections/tickets.js");
require("./collections/userRole.js");
require("./collections/userRoles.js");
require("./server/fixtures.js");
require("./server/publish.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
